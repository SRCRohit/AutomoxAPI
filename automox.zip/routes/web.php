<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeController::class, 'index'])->name('dashboard');
Route::any('/manage-company', [HomeController::class, 'manage_company'])->name('managecompany');
Route::get('/company-access', [HomeController::class, 'company_access'])->name('companyaccess');
Route::get('/company-view', [HomeController::class, 'company_view'])->name('companyview');
Route::any('/user-activity-report', [HomeController::class, 'user_activity_report'])->name('useractivityreport');
Route::any('/device-report', [HomeController::class, 'device_report'])->name('devicereport');
Route::get('/prepatch-report', [HomeController::class, 'prepatch_report'])->name('prepatchreport');
Route::any('/data-extract', [HomeController::class, 'data_extract'])->name('dataextract');
Route::get('/run-cron-job', [HomeController::class, 'cron_job'])->name('runcronjob');
Route::get('/run-company-cron', [HomeController::class, 'cron_job_company'])->name('cronjobcompany');
Route::get('/run-org-cron', [HomeController::class, 'organisation_in_company'])->name('organisationincompany');
Route::get('/run-device-cron', [HomeController::class, 'devices_in_organisation'])->name('devicesinorganisation');
Route::any('/manage-user', [HomeController::class, 'manage_user'])->name('manageuser');
Route::any('/profile', [HomeController::class, 'profile'])->name('profile');
Route::get('/error', [HomeController::class, 'error_view'])->name('errorview');
Route::get('/group-details', [HomeController::class, 'group_details'])->name('groupdetails');
Route::get('/device-information', [HomeController::class, 'device_information'])->name('deviceinformation');
Route::get('/needs-attention-report', [HomeController::class, 'needs_attention_report'])->name('needsattentionreport');
Route::get('/manual-approvals', [HomeController::class, 'manual_approvals'])->name('manualapprovals');
Route::get('/policies', [HomeController::class, 'policies'])->name('policies');
Route::get('/session', function () {
//    \Session::pull('device_information');
//    \Session::flush();
    dd(\Session::all());
});
Auth::routes();