

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/plugins/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/plugins/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/plugins/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/plugins/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="panel panel-inverse">
    <div class="panel-heading">
        <h4 class="panel-title">COMPANY ACCESS</h4>
    </div>
    <div class="panel-body">
        <div>
            <form action="<?php echo e(route('companyview')); ?>" method="get">
                <div class="row">
                    <div class="col-md-2">
                        <select class="form-control" name="organisation" required>
                            <option value="" <?php echo e($org == '' ? 'selected': ''); ?>>Select Organisation...</option>
                            <?php $__currentLoopData = $orgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($orgdata->id); ?>" <?php echo e($org == $orgdata->id? 'selected':''); ?>><?php echo e($orgdata->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group" id="default-daterange">
                            <input required type="text" value="<?php echo e($daterange); ?>" class="form-control" name="daterange">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                   
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary full-width">Apply Filter</button>
                        &nbsp;&nbsp;
                        <a class="btn btn-danger btn-block" href="<?php echo e(route('companyview')); ?>">
                            Clear Filter
                        </a>
                    </div>
                </div>
            </form>
        </div>
        <div style="margin-top : 1rem">
            <table id="data-table-default" class="table table-striped table-bordered align-middle">
                <thead>
                    <tr>
                        <th data-orderable="false">ID</th>
                        <th data-orderable="false">Company Name</th>
                        <th data-orderable="false">Account Status</th>
                        <th data-orderable="false">MSP</th>
                        <th data-orderable="false">License Activation Date</th>
                        <th data-orderable="false">License Expiry Date</th>
                        <th data-orderable="false">No. of Licensed Issued</th>
                        <th data-orderable="false">License Utilisation</th>
                    </tr>
                </thead>
                <tbody>
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('assets/plugins/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<script type="text/javascript">
    $('#data-table-default').DataTable({
        responsive: true
    });
    $("#default-daterange").daterangepicker({
        opens: "right",
        format: "YYYY-MM-DD",
        separator: " to ",
        maxDate: moment(),
    }, function (start, end) {
        $("#default-daterange input").val(start.format("DD-MM-YYYY") + " - " + end.format("DD-MM-YYYY"));
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\src-cyber\resources\views/company-view.blade.php ENDPATH**/ ?>