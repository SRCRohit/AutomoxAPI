<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>

    <meta charset="utf-8" />
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet"> 
    <link href="<?php echo e(asset('assets/css/vendor.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/default/app.min.css')); ?>" rel="stylesheet" />
    <style>
        body{
            font-family: 'Roboto', sans-serif;
        }
        .alert-danger{
            color: #fff;
            background-color: #f00;
        }
        .blink {
            animation: blink-animation 1s steps(5, start) infinite;
            -webkit-animation: blink-animation 1s steps(5, start) infinite;
        }
        @keyframes  blink-animation {
            to {
                visibility: hidden;
            }
        }
        @-webkit-keyframes blink-animation {
            to {
                visibility: hidden;
            }
        }
    </style>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>

    <div id="loader" class="app-loader">
        <span class="spinner"></span>
    </div>


    <div id="app" class="app app-header-fixed app-sidebar-fixed">

        <div id="header" class="app-header app-header-inverse">

            <div class="navbar-header">
                <a href="/" class="navbar-brand">
                    <img src="<?php echo e(asset('assets/img/logo/logo.png')); ?>" class="img-fluid">
                </a>
                <button type="button" class="navbar-mobile-toggler" data-toggle="app-sidebar-mobile">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>


            <div class="navbar-nav">

                <div class="navbar-item navbar-user dropdown">
                    <a href="#" class="navbar-link dropdown-toggle d-flex align-items-center" data-bs-toggle="dropdown">
                        <img src="<?php echo e(asset('assets/img/user/user-13.jpg')); ?>" alt="" />
                        <span>
                            <span class="d-none d-md-inline"><?php echo e(Auth::user()->name); ?></span>
                            <b class="caret"></b>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end me-1">
                        <a href="<?php echo e(route('profile')); ?>" class="dropdown-item">Edit Profile</a>
                        <a href="javascript:;" onclick="document.getElementById('logout-form').submit();" class="dropdown-item">Log Out</a>
                    </div>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>

        </div>

        <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="app-sidebar-bg"></div>
        <div class="app-sidebar-mobile-backdrop"><a href="#" data-dismiss="app-sidebar-mobile" class="stretched-link"></a></div>


        <div id="content" class="app-content">
            <?php
                $companies = \App\Models\Company::all();
            ?>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $date1 = new DateTime(date('Y-m-d'));
                    $date2 = new DateTime($company->api_expires_at);
                    $days  = $date2->diff($date1)->format('%a');
                ?>
                <?php if($days <= 15): ?>
                    <div class="alert alert-danger fade show">
                        <h5 class="m-0 p-0 blink">The API key for <?php echo e($company->name); ?> is going to expire in <?php echo e($days); ?> <?php echo e(($days==1?'day':'days')); ?>.</h5>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>


    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>" type="text/javascript"></script>
    <script>
        function showLoader(){
            $('#loader').removeClass('loaded');
        }

        function hideLoader(){
            $('#loader').addClass('loaded');
        }
        var search = window.location.search;
        var hrefname = window.location.href;
        hrefname = hrefname.replace(search, '');
        if('dashboard' == '<?php echo e(Route::currentRouteName()); ?>'){
            hrefname = hrefname.replace(/.$/,"");
        }
        $('[href="'+hrefname+'"]').parent('.menu-item').addClass('active');
        setTimeout(function () {
            $('div.alert').hide();
        }, 10000)
    </script>
    <?php echo $__env->yieldContent('javascript'); ?>
</body>

</html><?php /**PATH /home/srccyber/public_html/new/resources/views/layouts/app.blade.php ENDPATH**/ ?>