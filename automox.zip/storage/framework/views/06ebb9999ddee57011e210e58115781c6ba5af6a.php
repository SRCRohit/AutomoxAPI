<div id="sidebar" class="app-sidebar">

    <div class="app-sidebar-content" data-scrollbar="true" data-height="100%">

        <div class="menu">
            <div class="menu-header">Navigation</div>

            <div class="menu-item">
                <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                    <div class="menu-icon">
                        <i class="fa fa-chevron-circle-right"></i>
                    </div>
                    <div class="menu-text">Dashboard</div>
                </a>
            </div>

            <div class="menu-item">
                <a href="<?php echo e(route('companyaccess')); ?>" class="menu-link">
                    <div class="menu-icon">
                        <i class="fa fa-chevron-circle-right"></i>
                    </div>
                    <div class="menu-text">Company Access</div>
                </a>
            </div>

            <div class="menu-item">
                <a href="<?php echo e(route('companyview')); ?>" class="menu-link">
                    <div class="menu-icon">
                        <i class="fa fa-chevron-circle-right"></i>
                    </div>
                    <div class="menu-text">Company View</div>
                </a>
            </div>

            <div class="menu-item">
                <a href="<?php echo e(route('useractivityreport')); ?>" class="menu-link">
                    <div class="menu-icon">
                        <i class="fa fa-chevron-circle-right"></i>
                    </div>
                    <div class="menu-text">User Activity Report</div>
                </a>
            </div>

            <div class="menu-item">
                <a href="<?php echo e(route('prepatchreport')); ?>" class="menu-link">
                    <div class="menu-icon">
                        <i class="fa fa-chevron-circle-right"></i>
                    </div>
                    <div class="menu-text">Pre Patch Report</div>
                </a>
            </div>

        </div>

    </div>

</div><?php /**PATH E:\PROJECTS\src-cyber\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>