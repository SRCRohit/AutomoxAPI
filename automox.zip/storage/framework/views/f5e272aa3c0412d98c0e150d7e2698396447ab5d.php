

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" />
    <style type="text/css">

    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="panel panel-inverse">
        <div class="panel-heading">
            <h4 class="panel-title">DATA EXTRACT</h4>
        </div>
        <div class="panel-body">
            <div>
                <form action="<?php echo e(route('dataextract')); ?>" method="get">
                    <input type="hidden" name="company" id="company" value="<?php echo e(($company_detail?$company_detail->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <select class="form-control default-select2" name="organisation" required  onchange="$('#company').val($('option:selected',this).data('company'))" >
                                <option value="" <?php echo e($org == '' ? 'selected': ''); ?>>Select Organisation...</option>
                                <?php $__currentLoopData = \App\Models\Company::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <optgroup label="<?php echo e($company->name); ?>">
                                        <?php $__currentLoopData = $company->organisation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option data-company="<?php echo e($company->id); ?>" value="<?php echo e($orgdata->org_id); ?>" <?php echo e($org ==
                                        $orgdata->org_id?
                                        'selected':''); ?>><?php echo e($orgdata->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select class="form-control" name="type">
                                <option value="patch-history" <?php echo e(($type=='patch-history'?'selected':'')); ?>>Patch
                                    History</option>
                                <option value="api-activity" <?php echo e(($type=='api-activity'?'selected':'')); ?>>API
                                    Activity</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <select class="form-control multi-select2" name="status[]" multiple>
                                <option value="queued" <?php echo e((in_array('queued', $status)?'selected':'')); ?>>Queued</option>
                                <option value="running" <?php echo e((in_array('running', $status)?'selected':'')); ?>>Running</option>
                                <option value="complete" <?php echo e((in_array('complete', $status)?'selected':'')); ?>>Complete</option>
                                <option value="failed" <?php echo e((in_array('failed', $status)?'selected':'')); ?>>Failed</option>
                                <option value="canceled" <?php echo e((in_array('canceled', $status)?'selected':'')); ?>>Canceled</option>
                                <option value="expired" <?php echo e((in_array('expired', $status)?'selected':'')); ?>>Expired</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
            <div style="margin-top : 1rem">
                <table id="data-table-default" class="table table-striped table-bordered align-middle">
                    <thead>
                    <tr>
                        <th data-orderable="false">ID</th>
                        <th data-orderable="false">Company</th>
                        <th data-orderable="false">MSP</th>
                        <th data-orderable="false">User</th>
                        <th data-orderable="false">Date Requested</th>
                        <th data-orderable="false">Date Range</th>
                        <th data-orderable="false">Extract Expiration</th>
                        <th data-orderable="false">Type</th>
                        <th data-orderable="false">Status</th>
                        <th data-orderable="false">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if($data): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($extract->id); ?></td>
                                    <td><?php echo e($orgs->name); ?></td>
                                    <td><?php echo e($company_detail->name); ?></td>
                                    <td><?php echo e($extract->username); ?></td>
                                    <td><?php echo e(explode('T',$extract->created_at)[0]); ?></td>
                                    <td><?php echo e(explode('T',$extract->parameters->start_time)[0]); ?> - <?php echo e(explode('T',$extract->parameters->end_time)[0]); ?></td>
                                    <td><?php echo e(explode('T', $extract->download_expires_at)[0]); ?></td>
                                    <td><?php echo e(ucwords(str_replace('-',' ',$type))); ?></td>
                                    <td><?php echo e(ucwords($extract->status)); ?></td>
                                    <td>
                                        <?php if($extract->download_url): ?>
                                            <a class="btn btn-dark btn-xs" href="<?php echo e($extract->download_url); ?>"
                                               target="_blank">Download</a>
                                        <?php else: ?>
                                            <a href="javascript:;" class="btn btn-dark btn-xs disabled">Download</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-activity">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">USER ACTIVITY FOR USER : <span id="for-user"
                                                                           class="text-danger"></span></h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                </div>
                <div class="modal-body">
                    <table style="width: 100%" id="data-table-activity" class="table table-striped table-bordered
                    align-middle">
                        <thead>
                        <tr>
                            <th data-orderable="false">Event Id</th>
                            <th data-orderable="false">Event Type</th>
                            <th data-orderable="false">Organisation</th>
                            <th data-orderable="false">Name</th>
                            <th data-orderable="false">Email Id</th>
                            <th data-orderable="false">Time</th>
                        </tr>
                        </thead>
                        <tbody id="activity_data">

                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <a href="javascript:;" class="btn btn-white" data-bs-dismiss="modal">Close</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/dist/js/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(".default-select2").select2();
        $(".multi-select2").select2({ placeholder: "Select status..." });
        $('#data-table-default').DataTable({
            responsive: true,
        });
        function getUserActivity(userid) {
            showLoader();
            $('#for-user').html(userid);
            $.post('<?php echo e(route('useractivityreport')); ?>',{ _token : $('meta[name=csrf-token]').attr('content') ,
                'organisation' : <?php echo e(($org?$org:0)); ?>,'user_id' : userid , 'company' : $('#company').val()},function (response) {
                $('#data-table-activity').DataTable().clear().destroy();
                $('#activity_data').html(response);
                $('#data-table-activity').DataTable({
                    responsive: true,
                    dom: '<"row"<"col-sm-5"B><"col-sm-7"fr>>t<"row"<"col-sm-5"i><"col-sm-7"p>>',
                    buttons: [
                        { extend: 'copy', className: 'btn-sm' },
                        { extend: 'csv', className: 'btn-sm' },
                        { extend: 'excel', className: 'btn-sm' },
                        { extend: 'pdf', className: 'btn-sm' },
                        { extend: 'print', className: 'btn-sm' }
                    ],
                });
                hideLoader();
                $('#modal-activity').modal('show');
            });
        }
        $("#default-daterange").daterangepicker({
            opens: "right",
            format: "YYYY-MM-DD",
            separator: " to ",
            maxDate: moment(),
            ranges: {
                "Today": [moment(), moment()],
                "Yesterday": [moment().subtract(1, "days"), moment().subtract(1, "days")],
                "Last 7 Days": [moment().subtract(6, "days"), moment()],
                "Last 30 Days": [moment().subtract(29, "days"), moment()],
                "This Month": [moment().startOf("month"), moment().endOf("month")],
                "Last Month": [moment().subtract(1, "month").startOf("month"), moment().subtract(1, "month").endOf("month")]
            }
        }, function (start, end) {
            $("#default-daterange input").val(start.format("DD-MM-YYYY") + " - " + end.format("DD-MM-YYYY"));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/srccyber/public_html/new/resources/views/data-extract.blade.php ENDPATH**/ ?>