<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Company User Count</title>
    <style>
        *{
            font-family: 'Helvetica' ;
        }
        table{
            border-collapse: collapse;
            width: 100%;
            font-size: 12px;
            font-family: "Courier New";
        }
        tr:nth-child(even) {
            background-color: lightgrey;
        }
        .text-center{
            text-align: center;
        }
    </style>
</head>
<body>
<h2 class="text-center"><?php echo e($orgs->name); ?></h2>
<div style="margin-top : 1rem">
    <table border="1" id="data-table-default" class="table table-striped table-bordered align-middle">
        <thead>
        <tr>
            <th data-orderable="false">ID</th>
            <th data-orderable="false">Date</th>
            <th data-orderable="false">Company Name</th>
            <th data-orderable="false">Account Status</th>
            <th data-orderable="false">MSP</th>
            <th data-orderable="false">License Issue Date</th>
            <th data-orderable="false">License Expiry Date</th>
            <th data-orderable="false">No. of Licensed Issued</th>
        </tr>
        </thead>
        <tbody>
        <?php if($daterange): ?>
            <?php
            $startDate = date('Y-m-d', strtotime(explode(' - ', $daterange)[0]));
            $endDate = date('Y-m-d', strtotime(explode(' - ', $daterange)[1]));
            $startTime = strtotime($startDate);
            $endTime = strtotime($endDate);

            for ( $i = $startTime; $i <= $endTime; $i = $i + 86400 ) {
            $thisDate = date( 'Y-m-d', $i );
            $device_count = \App\Models\Device::where('organisation_id', $org)->where('company_id',
                $company_detail->id)->where
            ('create_time', '<=', $thisDate)->count();
            ?>
            <tr>
                <td class="text-center"><?php echo e($org); ?></td>
                <td class="text-center"><?php echo e($thisDate); ?></td>
                <td class="text-center"><?php echo e($orgs->name); ?></td>
                <td class="text-center">Active</td>
                <td class="text-center"> <?php echo e($company_detail->name); ?></td>
                <td class="text-center">
                    <?php echo e(explode('T',$orgs->create_time)[0]); ?>

                </td>
                <td class="text-center">
                    <?php echo e(($orgs->trial_end_time?explode('T',$orgs->trial_end_time)[0]:'N/A')); ?>

                </td>
                <td class="text-center"><?php echo e($device_count); ?></td>
            </tr>
            <?php
            }
            ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html><?php /**PATH /home/srccyber/public_html/new/resources/views/pdf/company-view.blade.php ENDPATH**/ ?>