

<?php $__env->startSection('css'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-inverse">
    <div class="panel-heading">
        <h4 class="panel-title">PREPATCH REPORT</h4>
    </div>
    <div class="panel-body">
        <pre>
        <?php
            print_r(auth()->user());
        ?>
        </pre>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\src-cyber\resources\views/prepatch-report.blade.php ENDPATH**/ ?>