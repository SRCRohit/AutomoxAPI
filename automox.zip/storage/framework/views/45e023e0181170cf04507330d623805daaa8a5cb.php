<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Need Attention Report</title>
    <style>
        *{
            font-family: 'Helvetica' ;
        }
        table{
            border-collapse: collapse;
            width: 100%;
            font-size: 12px;
            font-family: "Courier New";
        }
        td, th{
            padding : 3px;
        }
        .text-center{
            text-align: center;
        }
        .badge {
            color: white;
            padding: 4px 8px;
            text-align: center;
            border-radius: 10px;
        }
        .bg-green{
            background-color: #32a932;
        }
        .bg-danger{
            background-color: #ff5b57;
        }
    </style>
</head>
<body>
<h2 class="text-center"><?php echo e($orgs->name); ?></h2>
<div style="margin-top : 1rem">
    <table border="1" id="data-table-default" class="table table-striped table-bordered align-middle">
        <thead>
        <tr>
            <th data-orderable="false" class="text-center">ID</th>
            <th data-orderable="false" class="text-center">Name</th>
            <th data-orderable="false" class="text-center">OS</th>
            <th data-orderable="false" class="text-center">Needs Reboot</th>
            <th data-orderable="false" class="text-center">Connected</th>
            <th data-orderable="false" class="text-center">Group Id</th>
        </tr>
        </thead>
        <tbody>
        <?php if(count($reports->devices)): ?>
            <?php $__currentLoopData = $reports->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($device->id); ?></td>
                    <td class="text-center"><?php echo e(($device->name ? $device->name : $device->customName)); ?></td>
                    <td class="text-center"><?php echo e($device->os_family); ?></td>
                    <td class="text-center">
                                    <span class="badge bg-<?php echo e(($device->needsReboot?'danger':'green')); ?> rounded-pill">
                                        <?php echo e(($device->needsReboot?'YES':'NO')); ?>

                                    </span>
                    </td>
                    <td class="text-center">
                                    <span class="badge bg-<?php echo e(($device->connected?'green':'danger')); ?> rounded-pill">
                                        <?php echo e(($device->connected?'YES':'NO')); ?>

                                    </span>
                    </td>
                    <td class="text-center"><?php echo e($device->groupId); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html><?php /**PATH /home/srccyber/public_html/new/resources/views/pdf/need-attention-report.blade.php ENDPATH**/ ?>