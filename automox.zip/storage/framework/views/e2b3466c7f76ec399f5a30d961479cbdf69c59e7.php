<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Device Information</title>
    <style>
        *{
            font-family: 'Helvetica' ;
        }
        table{
            border-collapse: collapse;
            width: 100%;
            font-size: 12px;
            font-family: "Courier New";
        }
        th, td{
            padding: 3px;
        }
        .text-center{
            text-align: center;
        }
        .text-left{
            text-align: left;
        }
        .badge {
            color: white;
            padding: 4px 8px;
            text-align: center;
            border-radius: 10px;
        }
        .bg-green{
            background-color: #32a932;
        }
        .bg-danger{
            background-color: #ff5b57;
        }
    </style>
</head>
<body>
<h2 class="text-center"><?php echo e($orgs->name); ?></h2>
<?php
    $info = \Session::get('device_information');
?>
<div style="margin-top : 1rem">
    <table border="1" id="data-table-default" class="table table-striped table-bordered align-middle">
        <thead>
        <tr>
            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value == 1): ?>
                    <th data-orderable="false"><?php echo e($key); ?></th>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        </thead>
        <tbody>
        <?php if($devices): ?>
            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($info['Device ID']): ?>
                        <td><?php echo e($device->id); ?></td>
                    <?php endif; ?>
                    <?php if($info['Device Name']): ?>
                            <td><?php echo e(($device->display_name?$device->display_name:$device->custom_name)); ?></td>
                    <?php endif; ?>
                    <?php if($info['OS']): ?>
                            <td><?php echo e($device->os_family); ?> <?php echo e($device->os_name); ?></td>
                    <?php endif; ?>
                    <?php if($info['Need Attention']): ?>
                            <td>
                                <?php if($device->needs_reboot): ?>
                                    <span class="badge rounded-pill bg-danger">
                                            Needs Reboot
                                        </span>
                                <?php endif; ?>
                            </td>
                    <?php endif; ?>
                    <?php if($info['Disconnect Time']): ?>
                        <td>
                            <?php
                                $dt = new DateTime($device->last_disconnect_time, new DateTimeZone("UTC"));
                                echo $dt->format("d M Y H:i:s O");
                            ?>
                        </td>
                    <?php endif; ?>
                    <?php if($info['Group Id']): ?>
                        <td><?php echo e($device->server_group_id); ?></td>
                    <?php endif; ?>
                    <?php if($info['Tags']): ?>
                        <td>
                            <?php if($device->tags): ?>
                                <?php $__currentLoopData = $device->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-yellow text-dark"><?php echo e($tag); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>

                    <?php if($info['IP Address']): ?>
                        <td>
                            <?php if($device->ip_addrs): ?>
                                <?php echo e($device->ip_addrs[0]); ?>

                            <?php endif; ?>
                        </td>
                    <?php endif; ?>

                    <?php if($info['OS Version']): ?>
                        <td><?php echo e($device->os_version); ?></td>
                    <?php endif; ?>
                    <?php if($info['Scheduled Patches']): ?>
                        <td><?php echo e($device->pending_patches); ?></td>
                    <?php endif; ?>
                    <?php if($info['Status']): ?>
                        <td>
                            <p class="p-0 m-0">Device Status : <?php echo e(ucwords($device->status->device_status)); ?></p>
                            <p class="p-0 m-0">Agent Status : <?php echo e(ucwords($device->status->agent_status)); ?></p>
                            <p class="p-0 m-0">Policy Status : <?php echo e(ucwords($device->status->policy_status)); ?></p>
                        </td>
                    <?php endif; ?>
                    <?php if($info['Agent Version']): ?>
                        <td><?php echo e($device->agent_version); ?></td>
                    <?php endif; ?>

                    <?php if($info['Disconnected For']): ?>
                        <td>
                            <?php
                                $start = new DateTime($device->last_disconnect_time, new DateTimeZone("UTC"));
                                $end = new DateTime("now", new DateTimeZone('UTC'));
                                echo ($start->diff($end)->days);
                            ?>
                        </td>
                    <?php endif; ?>
                    <?php if($info['Last Logged In User']): ?>
                        <td><?php echo e($device->last_logged_in_user); ?></td>
                    <?php endif; ?>
                    <?php if($info['Active Directory OU']): ?>
                        <td>-</td>
                    <?php endif; ?>
                    <?php if($info['Total Patched']): ?>
                        <td><?php echo e($device->patches); ?></td>
                    <?php endif; ?>
                    <?php if($info['Created']): ?>
                        <td>
                            <?php
                                $time = new DateTime($device->create_time, new DateTimeZone("UTC"));
                                echo $time->format("d M Y H:i:s");
                            ?>
                        </td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html><?php /**PATH /home/srccyber/public_html/new/resources/views/pdf/device-information.blade.php ENDPATH**/ ?>