

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" />
    <style type="text/css">
        .table-critical{
            background-color : rgba(246, 81, 163, .5);
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="panel panel-inverse">
        <div class="panel-heading">
            <h4 class="panel-title">GROUP DETAILS</h4>
        </div>
        <div class="panel-body">
            <div>
                <form action="<?php echo e(route('groupdetails')); ?>" method="get">
                    <input type="hidden" name="company" id="company" value="<?php echo e(($company_detail?$company_detail->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <select class="form-control default-select2" name="organisation" required  onchange="$('#company').val($('option:selected',this).data('company'))" >
                                <option value="" <?php echo e($org == '' ? 'selected': ''); ?>>Select Organisation...</option>
                                <?php $__currentLoopData = \App\Models\Company::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <optgroup label="<?php echo e($company->name); ?>">
                                        <?php $__currentLoopData = $company->organisation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option data-company="<?php echo e($company->id); ?>" value="<?php echo e($orgdata->org_id); ?>" <?php echo e($org ==
                                        $orgdata->org_id?
                                        'selected':''); ?>><?php echo e($orgdata->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-7">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <?php if($groups): ?>
                                &nbsp;
                                <a target="_blank" href="<?php echo e(url()->full()); ?>&excel=1" class="btn btn-dark"><i class="fa
                            fa-file-excel me-1"></i> Download Excel</a>
                                &nbsp;
                                <a target="_blank" href="<?php echo e(url()->full()); ?>&csv=1" class="btn btn-dark"><i class="fa
                            fa-file-csv me-1"></i> Download CSV</a>
                                &nbsp;
                                <a target="_blank" href="<?php echo e(url()->full()); ?>&pdf=1" class="btn btn-dark"><i class="fa
                            fa-file-pdf
                            me-1"></i>
                                    Download PDF</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
            <div style="margin-top : 1rem">
                <table id="data-table-default" class="table table-striped table-bordered align-middle">
                    <thead>
                    <tr>
                        <th data-orderable="false">ID</th>
                        <th data-orderable="false">Name</th>
                        <th data-orderable="false" class="text-center">Scan Interval</th>
                        <th data-orderable="false" class="text-center">Devices</th>
                        <th data-orderable="false" class="text-center">Policies</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if($groups): ?>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($group->id); ?></td>
                                        <td><?php echo e(($group->name ? $group->name : 'Default')); ?></td>
                                        <td class="text-center"><?php echo e(floor($group->refresh_interval / 60)); ?> hours</td>
                                        <td class="text-center"><?php echo e($group->server_count); ?></td>
                                        <td class="text-center"><?php echo e(count($group->policies)); ?></td>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/dist/js/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(".default-select2").select2();
        $('#data-table-default').DataTable({
            responsive: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/srccyber/public_html/new/resources/views/group-details.blade.php ENDPATH**/ ?>