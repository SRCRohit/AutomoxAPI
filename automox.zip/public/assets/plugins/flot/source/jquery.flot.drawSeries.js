(function($){"use strict";function DrawSeries(){function plotLine(datapoints,xoffset,yoffset,axisx,axisy,ctx,steps){var points=datapoints.points,ps=datapoints.pointsize,prevx=null,prevy=null;var x1=0.0,y1=0.0,x2=0.0,y2=0.0,mx=null,my=null,i=0;ctx.beginPath();for(i=ps;i<points.length;i+=ps){x1=points[i-ps];y1=points[i-ps+1];x2=points[i];y2=points[i+1];if(x1===null||x2===null){mx=null;my=null;continue;}
if(isNaN(x1)||isNaN(x2)||isNaN(y1)||isNaN(y2)){prevx=null;prevy=null;continue;}
if(steps){if(mx!==null&&my!==null){x2=x1;y2=y1;x1=mx;y1=my;mx=null;my=null;i-=ps;}else if(y1!==y2&&x1!==x2){y2=y1;mx=x2;my=y1;}}
if(y1<=y2&&y1<axisy.min){if(y2<axisy.min){continue;}
x1=(axisy.min-y1)/(y2-y1)*(x2-x1)+x1;y1=axisy.min;}else if(y2<=y1&&y2<axisy.min){if(y1<axisy.min){continue;}
x2=(axisy.min-y1)/(y2-y1)*(x2-x1)+x1;y2=axisy.min;}
if(y1>=y2&&y1>axisy.max){if(y2>axisy.max){continue;}
x1=(axisy.max-y1)/(y2-y1)*(x2-x1)+x1;y1=axisy.max;}else if(y2>=y1&&y2>axisy.max){if(y1>axisy.max){continue;}
x2=(axisy.max-y1)/(y2-y1)*(x2-x1)+x1;y2=axisy.max;}
if(x1<=x2&&x1<axisx.min){if(x2<axisx.min){continue;}
y1=(axisx.min-x1)/(x2-x1)*(y2-y1)+y1;x1=axisx.min;}else if(x2<=x1&&x2<axisx.min){if(x1<axisx.min){continue;}
y2=(axisx.min-x1)/(x2-x1)*(y2-y1)+y1;x2=axisx.min;}
if(x1>=x2&&x1>axisx.max){if(x2>axisx.max){continue;}
y1=(axisx.max-x1)/(x2-x1)*(y2-y1)+y1;x1=axisx.max;}else if(x2>=x1&&x2>axisx.max){if(x1>axisx.max){continue;}
y2=(axisx.max-x1)/(x2-x1)*(y2-y1)+y1;x2=axisx.max;}
if(x1!==prevx||y1!==prevy){ctx.moveTo(axisx.p2c(x1)+xoffset,axisy.p2c(y1)+yoffset);}
prevx=x2;prevy=y2;ctx.lineTo(axisx.p2c(x2)+xoffset,axisy.p2c(y2)+yoffset);}
ctx.stroke();}
function plotLineArea(datapoints,axisx,axisy,fillTowards,ctx,steps){var points=datapoints.points,ps=datapoints.pointsize,bottom=fillTowards>axisy.min?Math.min(axisy.max,fillTowards):axisy.min,i=0,ypos=1,areaOpen=false,segmentStart=0,segmentEnd=0,mx=null,my=null;while(true){if(ps>0&&i>points.length+ps){break;}
i+=ps;var x1=points[i-ps],y1=points[i-ps+ypos],x2=points[i],y2=points[i+ypos];if(ps===-2){y1=y2=bottom;}
if(areaOpen){if(ps>0&&x1!=null&&x2==null){segmentEnd=i;ps=-ps;ypos=2;continue;}
if(ps<0&&i===segmentStart+ps){ctx.fill();areaOpen=false;ps=-ps;ypos=1;i=segmentStart=segmentEnd+ps;continue;}}
if(x1==null||x2==null){mx=null;my=null;continue;}
if(steps){if(mx!==null&&my!==null){x2=x1;y2=y1;x1=mx;y1=my;mx=null;my=null;i-=ps;}else if(y1!==y2&&x1!==x2){y2=y1;mx=x2;my=y1;}}
if(x1<=x2&&x1<axisx.min){if(x2<axisx.min){continue;}
y1=(axisx.min-x1)/(x2-x1)*(y2-y1)+y1;x1=axisx.min;}else if(x2<=x1&&x2<axisx.min){if(x1<axisx.min){continue;}
y2=(axisx.min-x1)/(x2-x1)*(y2-y1)+y1;x2=axisx.min;}
if(x1>=x2&&x1>axisx.max){if(x2>axisx.max){continue;}
y1=(axisx.max-x1)/(x2-x1)*(y2-y1)+y1;x1=axisx.max;}else if(x2>=x1&&x2>axisx.max){if(x1>axisx.max){continue;}
y2=(axisx.max-x1)/(x2-x1)*(y2-y1)+y1;x2=axisx.max;}
if(!areaOpen){ctx.beginPath();ctx.moveTo(axisx.p2c(x1),axisy.p2c(bottom));areaOpen=true;}
if(y1>=axisy.max&&y2>=axisy.max){ctx.lineTo(axisx.p2c(x1),axisy.p2c(axisy.max));ctx.lineTo(axisx.p2c(x2),axisy.p2c(axisy.max));continue;}else if(y1<=axisy.min&&y2<=axisy.min){ctx.lineTo(axisx.p2c(x1),axisy.p2c(axisy.min));ctx.lineTo(axisx.p2c(x2),axisy.p2c(axisy.min));continue;}
var x1old=x1,x2old=x2;if(y1<=y2&&y1<axisy.min&&y2>=axisy.min){x1=(axisy.min-y1)/(y2-y1)*(x2-x1)+x1;y1=axisy.min;}else if(y2<=y1&&y2<axisy.min&&y1>=axisy.min){x2=(axisy.min-y1)/(y2-y1)*(x2-x1)+x1;y2=axisy.min;}
if(y1>=y2&&y1>axisy.max&&y2<=axisy.max){x1=(axisy.max-y1)/(y2-y1)*(x2-x1)+x1;y1=axisy.max;}else if(y2>=y1&&y2>axisy.max&&y1<=axisy.max){x2=(axisy.max-y1)/(y2-y1)*(x2-x1)+x1;y2=axisy.max;}
if(x1!==x1old){ctx.lineTo(axisx.p2c(x1old),axisy.p2c(y1));}
ctx.lineTo(axisx.p2c(x1),axisy.p2c(y1));ctx.lineTo(axisx.p2c(x2),axisy.p2c(y2));if(x2!==x2old){ctx.lineTo(axisx.p2c(x2),axisy.p2c(y2));ctx.lineTo(axisx.p2c(x2old),axisy.p2c(y2));}}}
function drawSeriesLines(series,ctx,plotOffset,plotWidth,plotHeight,drawSymbol,getColorOrGradient){ctx.save();ctx.translate(plotOffset.left,plotOffset.top);ctx.lineJoin="round";if(series.lines.dashes&&ctx.setLineDash){ctx.setLineDash(series.lines.dashes);}
var datapoints={format:series.datapoints.format,points:series.datapoints.points,pointsize:series.datapoints.pointsize};if(series.decimate){datapoints.points=series.decimate(series,series.xaxis.min,series.xaxis.max,plotWidth,series.yaxis.min,series.yaxis.max,plotHeight);}
var lw=series.lines.lineWidth;ctx.lineWidth=lw;ctx.strokeStyle=series.color;var fillStyle=getFillStyle(series.lines,series.color,0,plotHeight,getColorOrGradient);if(fillStyle){ctx.fillStyle=fillStyle;plotLineArea(datapoints,series.xaxis,series.yaxis,series.lines.fillTowards||0,ctx,series.lines.steps);}
if(lw>0){plotLine(datapoints,0,0,series.xaxis,series.yaxis,ctx,series.lines.steps);}
ctx.restore();}
function drawSeriesPoints(series,ctx,plotOffset,plotWidth,plotHeight,drawSymbol,getColorOrGradient){function drawCircle(ctx,x,y,radius,shadow,fill){ctx.moveTo(x+radius,y);ctx.arc(x,y,radius,0,shadow?Math.PI:Math.PI*2,false);}
drawCircle.fill=true;function plotPoints(datapoints,radius,fill,offset,shadow,axisx,axisy,drawSymbolFn){var points=datapoints.points,ps=datapoints.pointsize;ctx.beginPath();for(var i=0;i<points.length;i+=ps){var x=points[i],y=points[i+1];if(x==null||x<axisx.min||x>axisx.max||y<axisy.min||y>axisy.max){continue;}
x=axisx.p2c(x);y=axisy.p2c(y)+offset;drawSymbolFn(ctx,x,y,radius,shadow,fill);}
if(drawSymbolFn.fill&&!shadow){ctx.fill();}
ctx.stroke();}
ctx.save();ctx.translate(plotOffset.left,plotOffset.top);var datapoints={format:series.datapoints.format,points:series.datapoints.points,pointsize:series.datapoints.pointsize};if(series.decimatePoints){datapoints.points=series.decimatePoints(series,series.xaxis.min,series.xaxis.max,plotWidth,series.yaxis.min,series.yaxis.max,plotHeight);}
var lw=series.points.lineWidth,radius=series.points.radius,symbol=series.points.symbol,drawSymbolFn;if(symbol==='circle'){drawSymbolFn=drawCircle;}else if(typeof symbol==='string'&&drawSymbol&&drawSymbol[symbol]){drawSymbolFn=drawSymbol[symbol];}else if(typeof drawSymbol==='function'){drawSymbolFn=drawSymbol;}
if(lw===0){lw=0.0001;}
ctx.lineWidth=lw;ctx.fillStyle=getFillStyle(series.points,series.color,null,null,getColorOrGradient);ctx.strokeStyle=series.color;plotPoints(datapoints,radius,true,0,false,series.xaxis,series.yaxis,drawSymbolFn);ctx.restore();}
function drawBar(x,y,b,barLeft,barRight,fillStyleCallback,axisx,axisy,c,horizontal,lineWidth){var left=x+barLeft,right=x+barRight,bottom=b,top=y,drawLeft,drawRight,drawTop,drawBottom=false,tmp;drawLeft=drawRight=drawTop=true;if(horizontal){drawBottom=drawRight=drawTop=true;drawLeft=false;left=b;right=x;top=y+barLeft;bottom=y+barRight;if(right<left){tmp=right;right=left;left=tmp;drawLeft=true;drawRight=false;}}else{drawLeft=drawRight=drawTop=true;drawBottom=false;left=x+barLeft;right=x+barRight;bottom=b;top=y;if(top<bottom){tmp=top;top=bottom;bottom=tmp;drawBottom=true;drawTop=false;}}
if(right<axisx.min||left>axisx.max||top<axisy.min||bottom>axisy.max){return;}
if(left<axisx.min){left=axisx.min;drawLeft=false;}
if(right>axisx.max){right=axisx.max;drawRight=false;}
if(bottom<axisy.min){bottom=axisy.min;drawBottom=false;}
if(top>axisy.max){top=axisy.max;drawTop=false;}
left=axisx.p2c(left);bottom=axisy.p2c(bottom);right=axisx.p2c(right);top=axisy.p2c(top);if(fillStyleCallback){c.fillStyle=fillStyleCallback(bottom,top);c.fillRect(left,top,right-left,bottom-top)}
if(lineWidth>0&&(drawLeft||drawRight||drawTop||drawBottom)){c.beginPath();c.moveTo(left,bottom);if(drawLeft){c.lineTo(left,top);}else{c.moveTo(left,top);}
if(drawTop){c.lineTo(right,top);}else{c.moveTo(right,top);}
if(drawRight){c.lineTo(right,bottom);}else{c.moveTo(right,bottom);}
if(drawBottom){c.lineTo(left,bottom);}else{c.moveTo(left,bottom);}
c.stroke();}}
function drawSeriesBars(series,ctx,plotOffset,plotWidth,plotHeight,drawSymbol,getColorOrGradient){function plotBars(datapoints,barLeft,barRight,fillStyleCallback,axisx,axisy){var points=datapoints.points,ps=datapoints.pointsize,fillTowards=series.bars.fillTowards||0,defaultBottom=fillTowards>axisy.min?Math.min(axisy.max,fillTowards):axisy.min;for(var i=0;i<points.length;i+=ps){if(points[i]==null){continue;}
var bottom=ps===3?points[i+2]:defaultBottom;drawBar(points[i],points[i+1],bottom,barLeft,barRight,fillStyleCallback,axisx,axisy,ctx,series.bars.horizontal,series.bars.lineWidth);}}
ctx.save();ctx.translate(plotOffset.left,plotOffset.top);var datapoints={format:series.datapoints.format,points:series.datapoints.points,pointsize:series.datapoints.pointsize};if(series.decimate){datapoints.points=series.decimate(series,series.xaxis.min,series.xaxis.max,plotWidth);}
ctx.lineWidth=series.bars.lineWidth;ctx.strokeStyle=series.color;var barLeft;var barWidth=series.bars.barWidth[0]||series.bars.barWidth;switch(series.bars.align){case "left":barLeft=0;break;case "right":barLeft=-barWidth;break;default:barLeft=-barWidth/2;}
var fillStyleCallback=series.bars.fill?function(bottom,top){return getFillStyle(series.bars,series.color,bottom,top,getColorOrGradient);}:null;plotBars(datapoints,barLeft,barLeft+barWidth,fillStyleCallback,series.xaxis,series.yaxis);ctx.restore();}
function getFillStyle(filloptions,seriesColor,bottom,top,getColorOrGradient){var fill=filloptions.fill;if(!fill){return null;}
if(filloptions.fillColor){return getColorOrGradient(filloptions.fillColor,bottom,top,seriesColor);}
var c=$.color.parse(seriesColor);c.a=typeof fill==="number"?fill:0.4;c.normalize();return c.toString();}
this.drawSeriesLines=drawSeriesLines;this.drawSeriesPoints=drawSeriesPoints;this.drawSeriesBars=drawSeriesBars;this.drawBar=drawBar;};$.plot.drawSeries=new DrawSeries();})(jQuery);