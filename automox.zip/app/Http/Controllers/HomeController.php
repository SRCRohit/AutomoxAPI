<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use PDF;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $companies = \App\Models\Company::all();
        if(count($companies)){
            return view('dashboard');
        }else{
            return redirect()->route('managecompany');
        }
    }

    public function error_view()
    {
        return view('error-view');
    }

    public function company_access(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org        = '';
        $users      = [];
        $orgs       = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){

            $org = $request->get('organisation');

            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }
        if($org) {

            $client = new Client();
            $url = "https://console.automox.com/api/users?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $users = json_decode($response->getBody());
        }
        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['ID','Company Name','MSP','Name','Email Id','Role','License Issue Date','License Expiry'];
            foreach($users as $user){
                $data[] = [
                    $user->id,
                    $orgs->name,
                    $company_detail->name,
                    $user->firstname.' '.$user->lastname,
                    $user->email,
                    $user->rbac_roles[array_search($org, array_column($user->rbac_roles, 'organization_id'))]->name,
                    explode('T',$orgs->create_time)[0],
                    ($orgs->trial_end_time?explode('T',$orgs->trial_end_time)[0]:'N/A')
                ];
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }
        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.company-access', compact('users', 'org', 'orgs', 'company_detail'))->setPaper('a4', 'landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }
        return view('company-access',compact('users', 'org', 'orgs', 'company_detail'));
    }
    
    public function company_view(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org        = '';
        $daterange  = '';
        $orgs       = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($request->has('daterange')){
            $daterange = $request->get('daterange');
        }

        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['ID','Date','Company Name','Account Status','MSP','License Issue Date','License Expiry Date','No. of Licensed Issued'];
            $startDate = date('Y-m-d', strtotime(explode(' - ', $daterange)[0]));
            $endDate = date('Y-m-d', strtotime(explode(' - ', $daterange)[1]));
            $startTime = strtotime($startDate);
            $endTime = strtotime($endDate);

            for ( $i = $startTime; $i <= $endTime; $i = $i + 86400 ) {
                $thisDate = date( 'Y-m-d', $i );
                $device_count = \App\Models\Device::where('organisation_id', $org)->where('company_id',$company_detail->id)->where('create_time', '<=', $thisDate)->count();
                $data[] = [
                    $org,
                    $thisDate,
                    $orgs->name,
                    'Active',
                    $company_detail->name,
                    explode('T',$orgs->create_time)[0],
                    ($orgs->trial_end_time?explode('T',$orgs->trial_end_time)[0]:'N/A'),
                    $device_count
                ];
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }
        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.company-view', compact('daterange','org', 'orgs', 'company_detail'))->setPaper('a4','landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }

        return view('company-view',compact('orgs', 'org', 'daterange', 'company_detail'));
    }

    public function user_activity_report(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org        = '';
        $daterange  = '';
        $users      = [];
        $orgs       = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }
        
        if($request->has('daterange')){
            if($request->get('daterange')){
                $daterange = $request->get('daterange');
                list($start, $end) = explode(' - ', $daterange);
                $start = date('Y-m-d', strtotime($start));
                $end = date('Y-m-d', strtotime($end));
            }
        }

        if($request->has('user_id')){
            $userId = $request->get('user_id');
            $client = new Client();
            if($daterange){
                $url = "https://console.automox.com/api/events?o=".$org."&userId=".$userId."&startDate=".$start."&endDate=".$end;
            }else{
                $url = "https://console.automox.com/api/events?o=".$org."&userId=".$userId;
            }
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $user_activity = json_decode($response->getBody());

            $table_data = '';
            if($user_activity){
                foreach($user_activity as $activity){
                    list($date, $time) = explode('T',$activity->create_time)[0];
                    $data_flg = 0;
                    if($activity->data){
                        $data_flg = 1;
                    }
                    $table_data .= '<tr><td>'.$activity->id.'</td><td>'.ucwords(str_replace('.', ' ', $activity->name)).'</td><td>'.($data_flg ? $activity->data->orgname : 'N/A').'</td><td>'.($data_flg?$activity->data->firstname.' '.$activity->data->lastname:'N/A').'</td><td>'.($data_flg?$activity->data->email:'N/A').'</td><td>'.date('Y-m-d H:i:s',strtotime($activity->create_time)).'</td></tr>';
                }
            }
            echo $table_data;
            exit;
        }

        if($org) {
            $client = new Client();
            $url = "https://console.automox.com/api/users?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $users = json_decode($response->getBody());
        }
        return view('user-activity-report',compact('users', 'orgs', 'org', 'daterange', 'company_detail'));
    }

    public function device_report(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org        = '';
        $daterange  = '';
        $users      = [];
        $orgs       = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($request->has('daterange')){
            if($request->get('daterange')){
                $daterange = $request->get('daterange');
                list($start, $end) = explode(' - ', $daterange);
                $start = date('Y-m-d', strtotime($start));
                $end = date('Y-m-d', strtotime($end));
            }
        }

        if($request->has('user_id')){
            $userId = $request->get('user_id');
            $client = new Client();
            if($daterange){
                $url = "https://console.automox.com/api/events?o=".$org."&serverId=".$userId."&startDate=".$start."&endDate=".$end;
            }else{
                $url = "https://console.automox.com/api/events?o=".$org."&serverId=".$userId;
            }
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $user_activity = json_decode($response->getBody());
            $table_data = '';
            if($user_activity){
                foreach($user_activity as $activity){
                    list($date, $time) = explode('T',$activity->create_time)[0];
                    $table_data .= '<tr><td>'.$activity->id.'</td><td>'.ucwords(str_replace('.', ' ',
                            $activity->name)).'</td><td>'.$activity->policy_id.'</td><td>'.$activity->policy_name.'</td><td>'.$activity->policy_type_name.'</td><td>'.date('Y-m-d H:i:s',strtotime($activity->create_time)).'</td></tr>';
                }
            }
            echo $table_data;
            exit;
        }

        if($org) {
            $users = \App\Models\Device::where('organisation_id', $org)->where('company_id', $company)->get();

            $client = new Client();
            $url = "https://console.automox.com/api/servergroups/?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $groups = json_decode($response->getBody(), TRUE);

            foreach ($users as $key => $user){
                $group_name = $groups[array_search($user->server_group_id, array_column($groups, 'id'))]['name'];
                $users[$key]->server_group_id = ($group_name?$group_name:'Default');
            }
        }
        return view('device-report',compact('users', 'orgs', 'org', 'daterange', 'company_detail'));
    }

    public function prepatch_report(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org = '';
        $orgs = '';
        $group = 0;
        $groups = [];
        $company_detail = '';
        $reports = [];

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($request->has('group')){
            $group = $request->get('group');
        }

        if($org) {
            $client = new Client();
            $url = "https://console.automox.com/api/servergroups?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $groups = json_decode($response->getBody());

            $client = new Client();
            $url = "https://console.automox.com/api/reports/prepatch?o=".$org.($group?"&groupId=".$group:"");
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $reports = json_decode($response->getBody());
        }

        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['Device ID','Device Name','Group','OS','Company Name','MSP','Software', 'Severity', 'Create Time','Patch Time'];
            if($reports) {
                if ($reports->prepatch->total) {
                    foreach ($reports->prepatch->devices as $report) {
                        foreach ($report->patches as $patch){
                            $data[] = [
                                $report->id,
                                $report->name,
                                $report->group,
                                $report->os_family,
                                $orgs->name,
                                $company_detail->name,
                                $patch->name,
                                ($patch->severity ? ucwords($patch->severity): 'Unknown'),
                                explode('T', $patch->createTime)[0],
                                explode('T', $patch->patchTime)[0]
                            ];
                        }
                        $data[] = ['','','','','','','', '', '',''];
                    }
                }
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }

        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.prepatch-report', compact('reports', 'orgs', 'org', 'group', 'groups', 'company_detail'))->setPaper('a4', 'landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }

        return view('prepatch-report',compact('reports', 'orgs', 'org', 'group', 'groups', 'company_detail'));
    }

    public function group_details(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org = '';
        $orgs = '';
        $groups = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($org) {
            $client = new Client();
            $url = "https://console.automox.com/api/servergroups?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $groups = json_decode($response->getBody());
        }

        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['Group ID','Group Name','Scan Interval','Device Count', 'Policies'];
            if($groups) {
                foreach ($groups as $group){
                    $data[] = [
                        $group->id,
                        ($group->name ? $group->name : 'Default'),
                        floor($group->refresh_interval / 60).' hours',
                        $group->server_count,
                        count($group->policies) ? count($group->policies) : '0'
                    ];
                }
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }

        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.group-details', compact('orgs', 'org', 'groups', 'company_detail'))->setPaper('a4', 'landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }

        return view('group-details',compact('orgs', 'org', 'groups', 'company_detail'));
    }

    public function manual_approvals(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org = '';
        $orgs = '';
        $approvals = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($org) {
            $client = new Client();
            $url = "https://console.automox.com/api/approvals?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $approvals = json_decode($response->getBody())->results;
        }

        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['Package ID','Package Name','OS','Status', 'Created', 'Policy'];
            if ($approvals) {
                foreach ($approvals as $approval){
                    if($approval->status != 'approved') {
                        $data[] = [
                            $approval->id,
                            $approval->software->display_name,
                            $approval->software->os_family,
                            ucwords($approval->status),
                            $approval->manual_approval_time,
                            $approval->policy->name
                        ];
                    }
                }
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }

        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.manual-approval', compact('orgs', 'org', 'approvals', 'company_detail'))->setPaper
            ('a4', 'landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }

        return view('manual-approval',compact('orgs', 'org', 'approvals', 'company_detail'));
    }

    public function needs_attention_report(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org = '';
        $orgs = '';
        $reports = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($org) {
            $client = new Client();
            $url = "https://console.automox.com/api/reports/needs-attention?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $reports = json_decode($response->getBody())->nonCompliant;
        }

        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['Device ID','Device Name','OS','Need Reboot', 'Connected', 'Group ID'];
            if(count($reports->devices)) {
                foreach ($reports->devices as $device){
                    $data[] = [
                        $device->id,
                        ($device->name ? $device->name : $device->customName),
                        $device->os_family,
                        ($device->needsReboot?'YES':'NO'),
                        ($device->connected?'YES':'NO'),
                        $device->groupId
                    ];
                }
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }

        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.need-attention-report', compact('orgs', 'org', 'reports', 'company_detail'))->setPaper('a4', 'landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }

        return view('need-attention-report',compact('orgs', 'org', 'reports', 'company_detail'));
    }

    public function policies(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org = '';
        $orgs = '';
        $policies = [];
        $company_detail = '';

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($org) {
            $client = new Client();
            $url = "https://console.automox.com/api/policies?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $policies = json_decode($response->getBody());
        }

        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['Policy ID','Policy Name','Type','Group Count','Device Count','Status','Created At'];
            if($policies) {
                foreach ($policies as $policy) {
                        $data[] = [
                            $policy->id,
                            $policy->name,
                            ucwords(str_replace('_', '', $policy->policy_type_name)),
                            count($policy->server_groups),
                            $policy->server_count,
                            $policy->status,
                            explode('T', $policy->create_time)[0]
                        ];
                }
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }

        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.policies', compact('orgs', 'org', 'policies', 'company_detail'))->setPaper('a4','landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }

        return view('policies',compact('orgs', 'org', 'policies', 'company_detail'));
    }

    public function device_information(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org = '';
        $orgs = '';
        $devices = [];
        $company_detail = '';

        if($request->has('text')){
            $text = $request->get('text');
            $old_values = \Session::get('device_information');
            $new_value = [$text => $request->get('status')];
            \Session::put('device_information' , array_merge($old_values,$new_value));
            \Session::save();
            echo 1;
            exit;
        }

        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            $org = $request->get('organisation');
            $client = new Client();
            $url = "https://console.automox.com/api/orgs";
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $orgs = json_decode($response->getBody());
            $key = array_search($org, array_column($orgs, 'id'));
            $orgs = $orgs[$key];
        }

        if($org) {
            $client = new Client();
            $url = "https://console.automox.com/api/servers?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $devices = json_decode($response->getBody());

            $client = new Client();
            $url = "https://console.automox.com/api/servergroups/?o=".$org;
            $response = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer '.$company_detail->api,
                ]
            ]);
            $groups = json_decode($response->getBody(), TRUE);

            foreach ($devices as $key => $device){
                $group_name = $groups[array_search($device->server_group_id, array_column($groups, 'id'))]['name'];
                $devices[$key]->server_group_id = ($group_name?$group_name:'Default');
            }
        }else{
            \Session::put('device_information', ['Device ID' => 1, 'Device Name' => 1, 'OS' => 1, 'Need Attention' => 1, 'Disconnect Time' => 1, 'Group Id' => 1, 'Tags' => 0, 'IP Address' => 0, 'OS Version' => 0, 'Scheduled Patches' => 0, 'Status' => 0, 'Agent Version' => 0, 'Disconnected For' => 0, 'Last Logged In User' => 0, 'Active Directory OU' => 0, 'Total Patched' => 0, 'Created' => 0]);
        }

        if($request->has('excel') || $request->has('csv')){
            $filename = $orgs->name.'.xlsx';
            if($request->has('csv')){
                $filename = $orgs->name.'.csv';
            }
            $data[] = ['Device ID','Device Name','OS','Need Attention','Disconnect Time','Group','Tags','IP Address','OS Version','Scheduled Patches','Status','Agent Version','Disconnected For','Last Logged In User','Active Directory OU','Total Patched','Created'];
            if($devices) {
                foreach ($devices as $device) {
                    $last_disconnect_time = new \DateTime($device->last_disconnect_time, new \DateTimeZone("UTC"));
                    $last_disconnect_time = $last_disconnect_time->format("d M Y H:i:s O");
                    $disconnected_for = new \DateTime("now", new \DateTimeZone('UTC'));
                    $last_disconnect = new \DateTime($device->last_disconnect_time, new \DateTimeZone("UTC"));
                    $disconnected_for = ($last_disconnect->diff($disconnected_for)->days);
                    $createtime = new \DateTime($device->create_time, new \DateTimeZone("UTC"));
                    $data[] = [
                        $device->id,
                        ($device->display_name?$device->display_name:$device->custom_name),
                        ($device->os_family.' '.$device->os_name),
                        ($device->needs_reboot?"Needs Reboot":''),
                        $last_disconnect_time,
                        $device->server_group_id,
                        ($device->tags?implode(', ', $device->tags):''),
                        ($device->ip_addrs?$device->ip_addrs[0]:''),
                        $device->os_version,
                        ($device->pending_patches?$device->pending_patches:'0'),
                        ucwords($device->status->device_status),
                        ucwords($device->status->agent_status),
                        ucwords($device->status->policy_status),
                        $device->agent_version,
                        $disconnected_for,
                        $device->last_logged_in_user,
                        '-',
                        ($device->patches?$device->patches:'0'),
                        $createtime->format("d M Y H:i:s")
                    ];
                }
            }
            $export = new ExcelExport($data);
            return \Excel::download($export, $filename);
        }

        if($request->has('pdf')){
            $pdf = Pdf::loadView('pdf.device-information', compact('orgs', 'org', 'devices', 'company_detail'))->setPaper('a4','landscape');
            return $pdf->stream($orgs->name.'.pdf');
        }

        return view('device-information',compact('orgs', 'org', 'devices', 'company_detail'));
    }

    public function data_extract(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        $org = '';
        $orgs = '';
        $company_detail = '';
        $data = [];
        $type = '';
        $status = [];
        if($request->has('company')){
            $company = $request->get('company');
            $company_detail = \App\Models\Company::where('id',$company)->first();
            if(!$company_detail){
                dd('Invalid Company details');
            }
        }

        if($request->has('organisation')){
            try {
                $org = $request->get('organisation');
                $client = new Client();
                $url = "https://console.automox.com/api/orgs";
                $response = $client->get($url, [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $company_detail->api,
                    ]
                ]);
                $orgs = json_decode($response->getBody());
                $key = array_search($org, array_column($orgs, 'id'));
                $orgs = $orgs[$key];
            }catch (\Exception $e){
                return view('error-page', ['code' => $e->getCode(), 'message' => getErrorMessage($e->getCode())]);
            }
        }

        if($org) {
            try {
                $client = new Client();
                $url = "https://console.automox.com/api/data-extracts?o=".$org."&sort=created_at:asc";
                if($request->has('type')){
                    if($request->get('type')){
                        $type = $request->get('type');
                        $url .= "&type:equals=".$request->get('type');
                    }
                }

                if($request->has('status')){
                    if($request->get('status')){
                        $status = $request->get('status');
                        $url .= "&status:in=".implode(',', $request->get('status'));
                    }
                }

                $response = $client->get($url, [
                    'headers' => [
                        'Authorization' => 'Bearer '.$company_detail->api,
                    ]
                ]);
                $data = json_decode($response->getBody());
                if($data->size){
                    $data = $data->results;
                    foreach ($data as $key => $d){
                        $client = new Client();
                        $url = "https://console.automox.com/api/users/".$d->user_id;
                        $response = $client->get($url, [
                            'headers' => [
                                'Authorization' => 'Bearer '.$company_detail->api,
                            ]
                        ]);
                        $user_data = json_decode($response->getBody());
                        $data[$key]->username = $user_data->firstname.' '.$user_data->lastname;
                    }
                }else{
                    $data = [];
                }
            }catch (\Exception $e){
                return view('error-page', ['code' => $e->getCode(), 'message' => getErrorMessage($e->getCode())]);
            }
        }
        return view('data-extract', compact( 'orgs', 'org',  'company_detail', 'data', 'type', 'status'));
    }

    public function manage_company(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        if($request->has('type')){
            $type = $request->get('type');
            if($type == 'insert'){
                $company = new \App\Models\Company;
                $company->name = $request->get('name');
                $company->api = $request->get('api');
                $company->organisation_id = $request->get('org_id');
                $company->user_id = $request->get('user_id');
                $company->save();
                company_update();
                organisation_insert();
                get_devices($company->id);
                return redirect()->back();
            }
            if($type == 'update'){
                $company = \App\Models\Company::find($request->get('company_id'));
                $company->name = $request->get('company_name');
                $company->save();
                return 1;
            }
            if($type == 'delete'){
                $company = \App\Models\Company::find($request->get('id'));
                $company->delete();
                \App\Models\Organisation::where('company_id', $request->get('id'))->delete();
                \App\Models\Device::where('company_id', $request->get('id'))->delete();
                return redirect()->back();
            }
            if($type == 'user_list'){
                try {
                    $client = new Client();
                    $url = "https://console.automox.com/api/users?o=" . $request->get('org_id');
                    $response = $client->get($url, [
                        'headers' => [
                            'Authorization' => 'Bearer ' . $request->get('api'),
                        ]
                    ]);
                    $users = json_decode($response->getBody());
                    $table_data = '';
                    if($users){
                        foreach($users as $user){
                            $table_data .= '<tr><td>'.$user->id.'</td><td>'.$user->firstname.' '.$user->lastname.'</td><td>'.$user->email
                                .'</td></tr>';
                        }
                    }
                    return $table_data;
                }catch (\Exception $e){
                    return response()->json(['error' => $e->getMessage()]);
                }
            }
        }
        return view('manage-company');
    }

    public function manage_user(Request $request)
    {
        if(!checkPermission()){
            return redirect()->route('errorview');
        }
        if($request->has('method_type')) {
            $type = $request->get('method_type');
            if ($type == 'insert') {
                //\App\Models\User::insert($request->insert);
                $insert = $request->get('insert');
                $insert['password'] = \Hash::make($insert['password']);
                $insert['permission'] = json_encode($insert['permission']);
                \App\Models\User::insert($insert);
                return redirect()->back();
            }
            if($type == 'delete'){
                $company = \App\Models\User::find($request->get('id'));
                $company->delete();
                return redirect()->back();
            }
        }
        return view('manage-user');
    }

    public function profile(Request $request)
    {
        if($request->has('method_type')) {
            $type = $request->get('method_type');
            if ($type == 'update') {
                $insert = $request->get('insert');
                if(!$insert['password']){
                    unset($insert['password']);
                }else{
                    $insert['password'] = \Hash::make($insert['password']);
                }
                \App\Models\User::where('id', $request->get('id'))->update($insert);
                return redirect()->back();
            }
        }
        return view('profile');
    }

    public function organisation_in_company()
    {
        organisation_insert();
    }

    public function devices_in_organisation()
    {
        get_devices();
    }

    public function cron_job_company()
    {
        company_update();
    }
}

class ExcelExport implements FromArray, ShouldAutoSize
{
    protected $data;

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function array(): array
    {
        return $this->data;
    }
}